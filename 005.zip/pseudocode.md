DOING:

- Show a splash page with setup options on first install.
  - Check for whether splash page needs showing on local and chrome storage.
  - Show page
  - Sync results to chrome storage (MVC-ish?)

BACKLOG:

- Create filter sets for "trigger warning" and "sexism"

- As a setup user, I can establish new filter words so that they never appear in my feed.
- As a setup upser, I can set block rules (hide, wrap, mute, allow) for different types of content.
- As a browsing user, I can opt-in to report my rules and what triggers them back to a central repository.
- Improve regex filtering to match for standalone words instead of substrings.
- Improve regex filtering to ignore URLs

DONE:

- As a browsing user, I can see why a thing was muted so that I can understand my current rules.
